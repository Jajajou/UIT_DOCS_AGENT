Tp.Hồ Chí Minh, ngày 30 tháng 8 năm 2019

# QUYẾT ĐỊNH Ban hành quy định đào tạo ngoại ngữ đối với hệ đại học chính quy của Trường Đại học Công nghệ Thông tin

# HIỆU TRƯỞNG TRƯỜNG ĐẠI HỌC CÔNG NGHỆ THÔNG TIN

Căn cứ Quyết định số 134/2006/QĐ-TTg, ngày 08/6/2006 của Thủ tướng Chính phủ về việc thành lập Trường Đại học Công nghệ thông tin (ĐHCNTT) thuộc Đại học Quốc gia Thành phố Hồ Chí Minh (ĐHQG-HCM);

Căn cứ Quyết định số 867/QĐ-ĐHQG-TCCB, ngày 17/8/2016 của Giám đốc ĐHQGHCM ban hành Quy chế tổ chức và hoạt động của trường đại học thành viên và khoa trực thuộcĐHQG-HCM;

Căn cứ Quyết định số 170/QĐ-ĐHQG, ngày 27/2/2018 của Giám đốc ĐHQG-HCM về việc ban hành Quy chế Chuẩn trình độ ngoại ngữ tại Đại học Quốc gia TPHCM.

Căn cứ Quyết định số 813/QĐ-ĐHCNTT, ngày 16/11/2017 của Hiệu trưởng Trường ĐHCNTT về việc ban hành Quy chế đào tạo theo học chế tín chỉ cho hệ đại học chính quy của TrườngĐHCNTT;

Xét đề nghị của Trưởng phòng Đào tạo Đại học;

# QUYẾT ĐỊNH:

Điều 1. Ban hành kèm theo Quyết định này “Quy định đào tạo ngoại ngữ đối với hệ đại học chính quy của Trường Đại học Công nghệ Thông tin”.

Điều 2. Quyết định có hiệu lực kể từ ngày ký.

Điều 3. Các Ông/Bà Trưởng các Phòng, Ban, Khoa, Bộ môn có liên quan chịu trách nhiệm thi hành Quyết định này.

# Nơi nhận:

- Như Điều 3; - Lưu: VT, ĐTĐH(Nh)

# KT.HIỆU TRƯỞNG PHÓ HIỆU TRƯỞNG

Đã ký

Vũ Đức Lung

# QUY ĐỊNH Đào tạo ngoại ngữ đối với hệ đại học chính quy của Trường Đại học Công nghệ Thông tin

(Ban hành kèm theo Quyết định số: 547/QĐ-ĐHCNTT, ngày 30 tháng 8 năm 201 của Hiệu trưởng Trường Đại học Công nghệ Thông tin)

# CHƯƠNG I NHỮNG QUY ĐỊNH CHUNG

# Điều 1. Phạm vi điều chỉnh và đối tượng áp dụng

1. Văn bản này quy định về đào tạo ngoại ngữ đối với các chương trình đào tạo hệ đại học chính quy của Trường Đại học Công nghệ Thông tin (gọi tắt là Trường) bao $\mathsf { g } \dot { \mathsf { o } } \mathsf { m }$ : chương trình giảng dạy, kiểm tra xếp lớp đầu khóa, xét miễn học các môn học tiếng Anh, chuẩn quá trình, chuẩn ngoại ngữ xét tốt nghiệp và tổ chức giảng dạy các môn học chuyên ngành bằng tiếng Anh.

2. Quy định này áp dụng với sinh viên các chương trình đại học chính quy bao gồm: chương trình đại trà (CTĐTr), chương trình tài năng (CTTN), chương trình chất lượng cao (CTCLC) và chương trình tiên tiến (CTTT).

# Điều 2. Mục đích đào tạo ngoại ngữ

1. Chương trình giảng dạy tiếng Anh nhằm mục đích giúp sinh viên:

a .Phát triển toàn diện 4 kỹ năng sử dụng tiếng Anh tổng quát: nghe, nói, đọc, viết; phát triển kỹ năng sử dụng tiếng Anh chuyên ngành ở mức độ phù hợp với trình độ đào tạo, ngành đào tạo và loại chương trình đào tạo.

b. Đáp ứng được chuẩn ngoại ngữ tiếng Anh đầu ra theo quy định của ĐHQG-HCM.

2. Các ngoại ngữ khác tiếng Anh được đưa vào nhằm khuyến khích sinh viên học để đáp ứng nhu cầu đa dạng của thị trường lao động.

3. Sinh viên chương trình đại trà, chương trình tài năng và chương trình chất lượng cao được chọn một trong các chứng chỉ ngoại ngữ: tiếng Anh, tiếng Nhật hoặc tiếng Pháp để xét tốt nghiệp, tuy nhiên sinh viên vẫn phải hoàn thành chương trình ngoại ngữ quy định tại Điều 3 (ngoại trừ chương trình CLC định hướng Nhật Bản). Việc xét chuẩn quá trình thực hiện theo Điều 8 của quy định này.

# CHƯƠNG II CHƯƠNG TRÌNH GIẢNG DẠY VÀ TỔ CHỨC ĐÀO TẠO NGOẠI NGỮ Điều 3. Chương trình giảng dạy tiếng Anh

1. Chương trình giảng dạy tiếng Anh của từng loại chương trình bao gồm những môn học được liệt kê theo cấp độ khó tăng dần như trong Bảng 1 nhằm hỗ trợ sinh viên đạt chuẩn ngoại ngữ xét tốt nghiệp theo quy định của từng chương trình. Đối với những môn học tiếng Anh nằm trong chương trình đào tạo được xét miễn học theo Điều 4 và Điều 5 của quy định này thì sinh viên được nhận điểm Miễn cho môn học đó và không tính vào điểm trung bình chung tích lũy, điểm trung bình tích lũy toàn khóa, điểm trung bình học kỳ.

Bảng 1. Chương trình giảng dạy tiếng Anh   

<table><tr><td rowspan=1 colspan=1>CTTr và CTTN</td><td rowspan=1 colspan=1>CTCLC</td><td rowspan=1 colspan=1>CTTT</td></tr><tr><td rowspan=1 colspan=1>Gm 3 môn hc:1. Anh văn 1 (ENG01)2. Anh văn 2 (ENG02)3. Anh văn 3 (ENG03)</td><td rowspan=1 colspan=1>Gm 5 môn hc:1. Anh văn 1 (ENG01)2. Anh văn 2 (ENG02)3. Anh văn 3 (ENG03)4. Anh văn 4 (ENG04)5. Anh văn 5 (ENG05)</td><td rowspan=1 colspan=1>Gm 8 môn hc:1.Anh văn 1 (ENG01)2Anh văn 2 (ENG02)3.Anh văn 3 (ENG03)4.Anh văn 4 (ENG04)5. Anh văn 5 (ENG05)6.Ting Anh 1 (ENGL1113)7. Ting Anh 2 (ENGL1213)8.Ting Anh chuyên ngành côngngh thông tin (SPCH3723)</td></tr></table>

2. Ngoài các môn học tiếng Anh tại Khoản 1 Điều này, trong chương trình đào tạo của ngành học có thể có nhữngmôn học chuyên ngành được giảng dạy bằng tiếng Anh nhằm cung cấp kiến thức tiếng Anh chuyên ngành và tạo môi trường cho sinh viên thực hành các kỹ năng tiếng Anh, gọi tắt là môn học Tiếng Anh chuyên môn (TACM). Những môn học đó được thiết kế và tổ chức giảng dạy tuân thủ theo các quy định tại Chương III của quy định này.

# Điều 4. Kiểm tra xếp lớp đầu khóa

1. Vào đầu khóa học, Trường tổ chức kiểm tra tiếng Anh để xếp lớp cho tất cả sinh viên khóa tuyển mới. Đề kiểm tra xếp lớp đầu khóa có dạng thức như đề thi TOEIC 2 kỹ năng (Nghe và Đọc). Căn cứ vào kết quả kiểm tra tiếng Anh, sinh viên được xếp vào lớp tiếng Anh phù hợp với trình độ của sinh viên theo Bảng 2.

Bảng 2. Xếp lớp đầu khóa   

<table><tr><td rowspan=1 colspan=1>Đim kim tra(dng thcTOEIC Nghevà Đc)</td><td rowspan=1 colspan=1>CTTr và CTTN</td><td rowspan=1 colspan=1>CTCLC</td><td rowspan=1 colspan=1>CTTT</td></tr><tr><td rowspan=1 colspan=1>&lt;300</td><td rowspan=1 colspan=2>Không đưc hc ENG01,hc AVSC ngoài CTT chính quydo TTNN ph trách (không bt buc)</td><td rowspan=2 colspan=1>HcENG01</td></tr><tr><td rowspan=1 colspan=1>300  345</td><td rowspan=1 colspan=2>Hc ENG01</td></tr><tr><td rowspan=1 colspan=1>350  395</td><td rowspan=1 colspan=3>Min ENG01;Hc ENG02</td></tr><tr><td rowspan=1 colspan=1>400  445</td><td rowspan=1 colspan=2>Min ENG01, ENG02;HcENG03</td><td rowspan=1 colspan=1>Min ENG01, ENG02;Hc ENG03</td></tr><tr><td rowspan=1 colspan=1>450  495</td><td rowspan=1 colspan=1>Min</td><td rowspan=1 colspan=1>Min ENG01  ENG03;Hc ENG04</td><td rowspan=1 colspan=1>Min ENG01 ENG03;Hc ENG04</td></tr><tr><td rowspan=1 colspan=1>≥500</td><td rowspan=1 colspan=1>ENG01#ENG03</td><td rowspan=1 colspan=1>Min ENG01  ENG04;HcENG05</td><td rowspan=1 colspan=1>Min ENG01 ENG04;HcENG05</td></tr></table>

2. Nếu không dự thi xếp lớp và không nộp chứng chỉ tiếng Anh, sinh viên được xếp vào trình độ tương ứng với điểm kiểm tra dưới 300 theo Bảng 2.

# Điều 5. Xét miễn các môn học tiếng Anh

1. Sinh viên được xét miễn học các môn tiếng Anh tương ứng nếu có một trong các chứng chỉ đạt trình độ tối thiểu theo quy định tại Bảng 3. Sinh viên được miễn môn học nào thì đồng thời được miễn những môn học ở cấp độ thấp hơn mà sinh viên chưa học hoặc chưa đạt.

Bảng 3.Điều kiện miễn học môn tiếng Anh   

<table><tr><td rowspan=1 colspan=5>Chng chi</td><td rowspan=1 colspan=3>Môn hc đưc min</td></tr><tr><td rowspan=1 colspan=1>TOEIC(NghevàĐc)</td><td rowspan=1 colspan=1>TOEFLiBT</td><td rowspan=1 colspan=1>IELTS</td><td rowspan=1 colspan=1>CambridgeEnglish</td><td rowspan=1 colspan=1>VNU-EPT</td><td rowspan=1 colspan=1>CTDTr/CTTN</td><td rowspan=1 colspan=1>CTCLC</td><td rowspan=1 colspan=1>CTTT</td></tr><tr><td rowspan=1 colspan=1>350</td><td rowspan=1 colspan=1>32</td><td rowspan=1 colspan=1>3.5</td><td rowspan=1 colspan=1>KET (Merit)</td><td rowspan=1 colspan=1>152</td><td rowspan=1 colspan=1>Anh văn 1</td><td rowspan=1 colspan=2>Anh văn 1</td></tr><tr><td rowspan=1 colspan=1>400</td><td rowspan=1 colspan=1>35</td><td rowspan=1 colspan=1>4.0</td><td rowspan=1 colspan=1>KET (Distinction)</td><td rowspan=1 colspan=1>165</td><td rowspan=1 colspan=1>Anh văn 2</td><td rowspan=1 colspan=2>Anh văn 2</td></tr><tr><td rowspan=1 colspan=1>450</td><td rowspan=1 colspan=1>45</td><td rowspan=1 colspan=1>4.5</td><td rowspan=1 colspan=1>PET(Pass)Business Preliminary(Pass)</td><td rowspan=1 colspan=1>176</td><td rowspan=1 colspan=1>Anh văn 3</td><td rowspan=1 colspan=2>Anh văn 3</td></tr><tr><td rowspan=1 colspan=1>500</td><td rowspan=1 colspan=1>50</td><td rowspan=1 colspan=1>5.0</td><td rowspan=1 colspan=1>PET(Merit)BusinessPreliminary(Merit)</td><td rowspan=1 colspan=1>201</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=2>Anh văn 4</td></tr><tr><td rowspan=1 colspan=1>555</td><td rowspan=1 colspan=1>60</td><td rowspan=1 colspan=1>5.5</td><td rowspan=1 colspan=1>PET(Distinction)FCE(Grade C)Business Preliminary(Distinction)Business Vantage(Grade C)</td><td rowspan=1 colspan=1>251</td><td rowspan=1 colspan=1></td><td rowspan=1 colspan=2>Anh văn 5</td></tr></table>

2. Hàng năm Trung tâm Ngoại ngữ của Trường sẽ tổ chức 4 đợt kiểm tra năng lực tiếng Anh và cấp chứng nhận, sinh viên có thể dùng chứng nhận nội bộ này để nộp xét miễn các môn tiếng Anh tương ứng theo quy định của Trường.

# Điều 6. Xét miễn các môn học tiếng Nhật đối với sinh viên thuộc chương trình chất lượng cao định hướng Nhật Bản

Sinh viên được xét miễn học các môn tiếng Nhật tương ứng trong chương trình đào tạo nếu có một trong các chứng chỉ đạt trình độ theo quy định tại Bảng 4. Sinh viên được miễn môn học nào thì đồng thời được miễn những môn học ở cấp độ thấp hơn mà sinh viên chưa học hoặc chưa đạt.

Bảng 4.Điều kiện miễn học môn tiếng Nhật   

<table><tr><td rowspan=1 colspan=2>Chng ch</td><td rowspan=1 colspan=1>Môn hc đưc min</td></tr><tr><td rowspan=1 colspan=1>JLPT</td><td rowspan=1 colspan=1>NAT-TEST</td><td rowspan=1 colspan=1>CTCLC đnh hưóngNht Bn</td></tr><tr><td rowspan=1 colspan=1>N5</td><td rowspan=1 colspan=1>N5</td><td rowspan=1 colspan=1>JAN01, JAN02</td></tr><tr><td rowspan=1 colspan=1>N4</td><td rowspan=1 colspan=1>N4</td><td rowspan=1 colspan=1>JAN01  JAN03</td></tr><tr><td rowspan=1 colspan=1>N3</td><td rowspan=1 colspan=1>N3</td><td rowspan=1 colspan=1>JAN01 → JAN06</td></tr><tr><td rowspan=1 colspan=1>N2</td><td rowspan=1 colspan=1>N2</td><td rowspan=1 colspan=1>JAN01 → JAN07</td></tr><tr><td rowspan=1 colspan=1>N1</td><td rowspan=1 colspan=1>N1</td><td rowspan=1 colspan=1>JAN01 → JAN08</td></tr></table>

# Điều 7. Thời điểm xét, cách tính điểm miễn các môn học ngoại ngữ

1. Trường xét miễn theo mỗi học kỳ, sinh viên đạt các chứng chỉ được quy định tại Điều 5, Điều 6 Quy định này, nộp bản sao chứng chỉ, chứng nhận còn hiệu lực cho Trường để được xét miễn các môn học tương ứng. Thời điểm nộp chứng chỉ, chứng nhận để xét miễn: 2 tuần cuối tháng 7 hàng năm (xét cho học kỳ 1) và 2 tuần cuối tháng 11 hàng năm (xét cho học kỳ 2).

2. Điểm miễn được tính cho học kỳ $\mathrm { k } \acute { \mathrm { e } }$ tiếp trong tiến trình học.

# Điều 8. Chuẩn quá trình về ngoại ngữ

1. Sau 2 học kỳ chính $\mathrm { k } \mathring { \mathrm { e } }$ từ thời điểm nhập học, sinh viên phải đạt môn Anh văn 1, nếu không đạt môn Anh văn 1, sinh viên chỉ được đăng ký tối đa 02 môn học ngoài các môn học ngoại ngữ (bao gồm cả đăng ký học lại hoặc cải thiện) cho đến khi đạt chuẩn.

2. Sau 4 học kỳ chính $\mathrm { k } \mathring { \mathrm { e } }$ từ thời điểm nhập học, sinh viên phải đạt môn Anh văn 2, nếu không đạt môn Anh văn 2, sinh viên chỉ được đăng ký tối đa 02 môn học ngoài các môn học ngoại ngữ (bao $\mathsf { g } \dot { \mathsf { o } } \mathsf { m }$ cả đăng ký học lại hoặc cải thiện) cho đến khi đạt chuẩn.

Sinh viên chương trình CLC định hướng Nhật Bản phải đạt môn tiếng Nhật 2 (JAN02) hoặc có chứng chỉ tương đương JLPT N5 hoặc NAT-TEST N5, ngược lại nếu không đạt sinh viên chỉ được đăng ký tối đa 02 môn học ngoài các môn học ngoại ngữ (bao gồm cả đăng ký học lại hoặc cải thiện) cho đến khi đạt chuẩn.

3. Sau 6 học kỳ chính kể từ thời điểm nhập học, sinh viên phải đạt môn Anh văn 3, nếu không đạt môn Anh văn 3, sinh viên chỉ được đăng ký tối đa 02 môn học ngoài các môn học ngoại ngữ (bao gồm cả đăng ký học lại hoặc cải thiện) cho đến khi đạt chuẩn.

4. Thời điểm nộp chứng chỉ để xét chuẩn quá trình: 2 tuần cuối tháng 7 hàng năm.

5. Không xét chuẩn quá trình đối với chương trình có ngoại ngữ khác tiếng Anh và tiếng Nhật.

# Điều 9. Chuẩn ngoại ngữ xét tốt nghiệp

1. Để được xét tốt nghiệp sinh viên phải hoàn tất các môn học tiếng Anh trong chương trình giảng dạy tiếng Anh tại Điều 3 và có một trong các loại chứng chỉ tiếng Anh đạt điểm tối thiểu trong Bảng 5; hoặc có chứng chỉ tiếng Pháp, hoặc tiếng Nhật tối thiểu tại Bảng 6.

Bảng 5. Chứng chỉ tiếng Anh dùng để xét công nhận tốt nghiệp   

<table><tr><td rowspan=2 colspan=1>ChúngchíChuro&#x27;ngtrình</td><td rowspan=1 colspan=2>TOEIC</td><td rowspan=2 colspan=1>TOEFLiBT</td><td rowspan=2 colspan=1>IELTS</td><td rowspan=2 colspan=1>CambridgeEnglish</td><td rowspan=2 colspan=1>VNU-EPT</td></tr><tr><td rowspan=1 colspan=1>Nghe vàĐc</td><td rowspan=1 colspan=1>Nói vàVit</td></tr><tr><td rowspan=1 colspan=1>CTTr</td><td rowspan=1 colspan=1>450</td><td rowspan=1 colspan=1>205</td><td rowspan=1 colspan=1>45</td><td rowspan=1 colspan=1>4.5</td><td rowspan=1 colspan=1>PET (Pass)BusinessPreliminary(Pass)</td><td rowspan=1 colspan=1>176</td></tr><tr><td rowspan=1 colspan=1>CTTN/CTCLC</td><td rowspan=1 colspan=1>555</td><td rowspan=1 colspan=1>205</td><td rowspan=1 colspan=1>60</td><td rowspan=1 colspan=1>5.5</td><td rowspan=1 colspan=1>PET(Distinction)FCE(Grade C)BusinessPreliminary(Distinction)BusinessVantage(Grade C)</td><td rowspan=1 colspan=1>201</td></tr><tr><td rowspan=1 colspan=1>CTTT</td><td rowspan=1 colspan=1>675</td><td rowspan=1 colspan=1>205</td><td rowspan=1 colspan=1>79</td><td rowspan=1 colspan=1>6.0</td><td rowspan=1 colspan=1>FCE(Grade B)BusinessVantage(Grade B)</td><td rowspan=1 colspan=1>251</td></tr></table>

Bảng 6. Chứng chỉ tiếng Pháp và tiếng Nhật dùng để xét công nhận tốt nghiệp   

<table><tr><td rowspan=1 colspan=1>Chng chChurongg trình</td><td rowspan=1 colspan=1>Ting Pháp</td><td rowspan=1 colspan=1>Ting Nht</td></tr><tr><td rowspan=1 colspan=1>CTĐTr</td><td rowspan=1 colspan=1>DELFB1 hocTCFNiveau 3</td><td rowspan=1 colspan=1>JLPTN4 hocNAT-TEST N4</td></tr><tr><td rowspan=1 colspan=1>CTCLC/ CTTN</td><td rowspan=1 colspan=1>DELFB2 hocTCF Niveau 4</td><td rowspan=1 colspan=1>JLPTN3hocNAT-TEST N3</td></tr></table>

2. Tại bất cứ thời điểm nào trong khóa học, sinh viên đạt các chứng chỉ thỏa điều kiện tại Khoản 1 của Điều này có thể nộp chứng chỉ cho Trường để được công nhận đạt chuẩn ngoại ngữ để xét tốt nghiệp. Chứng chỉ phải còn thời hạn hai năm tính từ ngày cấp chứng chỉ đến ngày đăng ký xét công nhận đạt chuẩn (ngày nộp chứng chỉ).

3. Việc công nhận các loại chứng chỉ khác do Hiệu trưởng xem xét và quyết định.

# CHƯƠNG III GIẢNG DẠY CHUYÊN NGÀNH BẰNG TIẾNG ANH

# Điều 10. Chương trình giảng dạy và tổ chức giảng dạy TACM

1. Môn học TACM đáp ứng các yêu cầu sau:   
a. Là các môn học thuộc khối kiến thức cơ bản, cơ sở hoặc chuyên ngành được giảng dạy chủ yếu bằng tiếng Anh. Nội dung giảng dạy hoàn toàn giống môn họcđược giảng dạy bằng tiếng Việt.   
b. Cán bộ giảng dạy (CBGD) lý thuyết phải giảng bằng tiếng Anh.   
c. Tài liệu giảng dạy và giáo trình chính của môn học bằng tiếng Anh.   
2. Để được tham gia học các lớp TACM, sinh viênphải có một trong các loại chứng chỉ tiếng Anh tương đươngTOEIC 400 tại Bảng 3 hoặc đã hoàn tất môn học Anh văn 2 (ENG02). 3. Mỗi lớp học TACM có tối thiểu 01 trợ giảng để hỗ trợ sinh viên trong quá trình học tập. Trợ giảng do CBGD lý thuyết chỉ định. Trợ giảng có thể sử dụng tiếng Việt trong quá trình hỗ trợ sinh viên.

# Điều 11. Yêu cầu về cán bộ giảng dạy TACM

CBGD phải đáp ứng yêu cầu theo quy định chung của Trường; ngoài ra, CBGD lý thuyết phải đáp ứng thêm một trong các yêu cầu sau đây:

1. Có trình độ tiếng Anh tối thiểu tương đương cấp độ C1 tham chiếu theo khung Châu Âu(CEFR).

2. Tốt nghiệp một trường đại học nước ngoài, có sử dụng tiếng Anh trong quá trình học tập (có môn học bằng tiếng Anh, hoặc luận án tốt nghiệp được viết bằng tiếng Anh).

3. Tốt nghiệp một trường đại học trong nước theo chương trình đào tạo sử dụng $100 \%$ tiếng Anh.

# Điều 12. Quyền lợi của sinh viên học TACM

Môn học TACM được ghi chú rõ về ngôn ngữ giảng dạy trong bảng điểm và giấy chứng nhận hoàn thành môn học.

# CHƯƠNG IV TỔ CHỨC THỰC HIỆN

# Điều 13. Trách nhiệm của đơn vị quản lý đào tạo

1. Quản lý đào tạo ngoại ngữ theo quy định này.   
2. Chủ trì tổ chức thi xếp lớp đầu khóa.   
3. Chủ trì tổ chức xét miễn học.

# Điều 14. Trách nhiệm của đơn vị chuyên mônphụ trách các môn học ngoại ngữ

1. Biên soạn chương trình, phân công giảng viên giảng dạy các môn học ngoại ngữ.   
2. Phối hợp tổ chức kiểm tra xếp lớp đầu khóa.   
3. Phối hợp xét miễn học các môn học ngoại ngữ.   
4. Phối hợp với Đơn vị quản lý đào tạo quản lýviệc đào tạo ngoại ngữ.

# Điều 15. Trách nhiệm của các Khoa/Bộ môn phụ trách các ngành

Biên soạn chương trình, tổ chức giảng dạy các môn học TACM.

# Điều 16. Phạm vi áp dụng

Quy định này áp dụng bắt buộc cho các khóa tuyển sinh từ năm 2019. Các khóa tuyển sinh trước năm 2019 có th $\hat { \dot { \mathrm { e } } }$ lựa chọn áp dụng quy định này hoặc quy định được ban hành trước đó.

# Điều 17. Điều khoản thi hành

Trong quá trình tổ chức thực hiện, tùy theo yêu cầu thực tế, Quy định này sẽ được sửa đổi, bổ sung cho phù hợp. Việc sửa đổi, bổ sung do Hiệu trưởng xem xét, quyết định./.

# KT.HIỆU TRƯỞNG PHÓ HIỆU TRƯỞNG

đã ký